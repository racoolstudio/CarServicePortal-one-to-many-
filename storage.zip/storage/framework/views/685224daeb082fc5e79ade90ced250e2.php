<a id="delete-link-<?php echo e($car->id); ?>" onclick="disableLink(event, <?php echo e($car->id); ?>)">
    <i id="delete-icon-<?php echo e($car->id); ?>" class="fa-solid fa-trash" style="color: #ec1313;"></i>
</a>

<form id="delete-<?php echo e($car->id); ?>" action="<?php echo e(route('car.destroy', ['car' => $car->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<script>
function disableLink(event, carId) {
    var link = event.currentTarget;
    link.classList.add('disabled');
    link.removeAttribute('onclick');
    document.getElementById('delete-' + carId).submit();
}
</script><?php /**PATH C:\laragon\www\Vehicle\resources\views/partials/deleteCar.blade.php ENDPATH**/ ?>