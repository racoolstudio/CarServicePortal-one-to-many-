<a id="delete-link-<?php echo e($owner->id); ?>" onclick="disableLink(event, <?php echo e($owner->id); ?>)">
    <i id="delete-icon-<?php echo e($owner->id); ?>" class="fa-solid fa-trash" style="color: #ec1313;"></i>
</a>

<form id="delete-<?php echo e($owner->id); ?>" action="<?php echo e(route('owner.destroy', ['owner' => $owner->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<script>
function disableLink(event, ownerId) {
    var link = event.currentTarget;
    link.classList.add('disabled');
    link.removeAttribute('onclick');
    document.getElementById('delete-' + ownerId).submit();
}
</script><?php /**PATH C:\laragon\www\Vehicle\resources\views/partials/deleteOwner.blade.php ENDPATH**/ ?>