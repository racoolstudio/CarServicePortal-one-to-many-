<?php
    require_once app_path('Helpers/formHelper.php');
?>


<?php $__env->startSection('title', 'Edit Owner'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.back', ['routeName' => 'owner.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="page-content mt-5">
        <div class="content-wrapper">
            <div class="content">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h5 class="mb-0">Update Owner </h5>
                    </div>
                    <div class="collapse show">
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('owner.update', ['owner' => $owner->id])); ?>" class="form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <?php echo $__env->make('partials.ownerform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="text-end">
                                    <button class="btn btn-success" type="submit"
                                        onclick="disableButton(this)">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function disableButton(button) {
                button.disabled = true; // disable the button after it's been clicked
                button.form.submit(); // submit the form
            }
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Vehicle\resources\views/Owner/edit.blade.php ENDPATH**/ ?>