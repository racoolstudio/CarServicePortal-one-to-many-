<div style="text-align: right; margin:50px auto;">
    <a href="<?php echo e(route("$routeName")); ?> " class = "add" >ADD</a>
</div><?php /**PATH C:\laragon\www\Vehicle\resources\views/partials/add.blade.php ENDPATH**/ ?>