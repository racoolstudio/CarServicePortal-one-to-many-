<?php if($errors->any()): ?>
    <div style="color :red">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="row mb-4">
    <label class="col-lg-3 col-form-label">Car Name</label>

    <div class="col-lg-9"><?php
    echo html_entity_decode(inputText('text', 'car_name', 'Car Name', old('car_name', $car->car_name ?? '')));
    ?>
    </div>

</div>

<div class="row mb-4">
    <label class="col-lg-3 col-form-label">Car Model</label>

    <div class="col-lg-9">
        <?php
        echo html_entity_decode(inputText('text', 'car_model', 'Car Model', old('car_model', $car->car_mode ?? '')));
        ?>
    </div>

</div>

<div class="row mb-4">
    <label class="col-lg-3 col-form-label">Owner</label>
    <div class="col-lg-9">
        <select name="owner_id" class="select">
            <option value="" <?php echo e(old('owner_id') === null ? 'selected' : ''); ?>>None</option>
            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($owner->id); ?>"
                    <?php echo e(old('owner_id', $car->owner_id ?? '') == $owner->id ? 'selected' : ''); ?>><?php echo e($owner->first_name); ?>

                    <?php echo e($owner->first_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH C:\laragon\www\Vehicle\resources\views/partials/form.blade.php ENDPATH**/ ?>