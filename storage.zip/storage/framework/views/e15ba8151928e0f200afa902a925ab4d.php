<div style="text-align: left; margin-top: 30px;margin-bottom: 30px;margin-left: 10px;">
    <a href="<?php echo e(route("$routeName")); ?> " class = "btn btn-danger" >Back</a>
</div><?php /**PATH C:\laragon\www\Vehicle\resources\views/partials/back.blade.php ENDPATH**/ ?>