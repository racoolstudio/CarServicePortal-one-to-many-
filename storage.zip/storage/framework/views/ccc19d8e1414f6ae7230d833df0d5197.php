
<?php $__env->startSection('title', $car->car_name); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.back', ['routeName' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-content mt-5">
        <div class="content-wrapper">
            <div class="content">
                <div class="card">
                    <div class="card-body mx-auto">
                        <h3 class="card-title ">Car Details</h3>

                        <h5 class="card-title">Name : <?php echo e($car->car_name); ?></h5>
                        <h5 class="card-title">Model : <?php echo e($car->car_model); ?></h5>


                        <h3 class="card-title mt-4">Owner Details</h3>

                        <h5 class="card-title">First Name: <?php echo e($car->owner->first_name); ?></h5>
                        <h5 class="card-title">Last Name: <?php echo e($car->owner->last_name); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Vehicle\resources\views/Car/show.blade.php ENDPATH**/ ?>