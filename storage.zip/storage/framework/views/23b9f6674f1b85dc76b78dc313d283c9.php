
<?php $__env->startSection('title', 'Car'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">

        <h1 class="text-center">Cars</h1>
        
        <?php echo $__env->make('partials.add',['routeName'=>'car.create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

        <div class="row mt-4 ">
            <?php $__empty_1 = true; $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4 mt-4">
                    
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Name : <?php echo e($car->car_name); ?></h5>
                            <h5 class="card-title">Model : <?php echo e($car->car_model); ?></h5>
                            <h5 class="card-text">Owner : <?php echo e($car->owner->first_name); ?> <?php echo e($car->owner->last_name); ?></h5>
                            <a href="<?php echo e(route('car.show', $car->id)); ?> " class="customButton text-center" >Get  </a>

                        </div>



                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h3 class="text-center">No Car!</h3>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Vehicle\resources\views/Car/index.blade.php ENDPATH**/ ?>