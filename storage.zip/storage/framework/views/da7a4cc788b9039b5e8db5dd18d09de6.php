
<?php $__env->startSection('title', $owner->first_name); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.back', ['routeName' => 'owner.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="page-content mt-5">
        <div class="content-wrapper">
            <div class="content">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Owner Details</h3>
                    </div>
                    
                        <div class="card-body mx-auto">
                            <h5 class="card-title">ID : <?php echo e($owner->id); ?></h5>
                            <h5 class="card-title">First Name : <?php echo e($owner->first_name); ?></h5>
                            <h5 class="card-title">Last Name : <?php echo e($owner->last_name); ?></h5>
                        </div>
          
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Vehicle\resources\views/Owner/show.blade.php ENDPATH**/ ?>